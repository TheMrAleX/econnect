# EConnect-module

Esto es un paquete de Python que permite a los desarrolladores cubanos interactuar de manera facil y sencilla con el Portal Cautivo de Etecsa.

# Caracteristicas
- Verificación de conexión.
- Inicio de Sesión.
- Guardado de datos para el cierre de manera local.
- Obtención de tiempo disponible.
- Cierre de sesión.
- Cierre de sesion de forma local con los datos guardados por el usuario

[Repositorio del proyecto aqui](https://guides.github.com/features/mastering-markdown/)
para los que se interesen en el código.<br>
[Documentacion del paquete](https://github.com/TheMrAleX/econnect/blob/main/README.md) para una ayuda de como usar el paquete correctamente.